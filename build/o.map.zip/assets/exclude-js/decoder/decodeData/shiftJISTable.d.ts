export declare const shiftJISTable: {
  [key: number]: number;
};
